﻿'
' Created by SharpDevelop.
' User: John Oliver Amurao
' Date: 4 Mar 2019
' Time: 1:05 AM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System.Data
Imports System.Data.OleDb
Imports System.Drawing


Public Partial Class BoarManagement
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	Dim db As New DatabaseHelper
	Dim mainMenu As New MainMenu
	
	Sub Label4Click(sender As Object, e As EventArgs)
		Try
			mainMenu.Show()
			mainMenu.lblCurrentUser.Text = Me.lblCurrentUser.Text
			Me.Hide()
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	
	End Sub
	
	Sub BoarManagementLoad(sender As Object, e As EventArgs)
		dataGridView1.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill
		loadData()
	End Sub
	
	Sub loadData()
		
		Try
			db.connection.Open()
			db.query = "select * from boar"
			Dim adapter As New OleDbDataAdapter(db.query, db.connection)
			Dim dt As New DataTable
			adapter.Fill(dt)
			dataGridView1.DataSource = dt
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	
	
	Sub DataGridView1CellClick(sender As Object, e As DataGridViewCellEventArgs)
		Try
			lblBoarID.Text = DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox1.Text = DataGridView1.Item(1, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox2.Text = DataGridView1.Item(2, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox3.Text = DataGridView1.Item(3, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox5.Text = DataGridView1.Item(4, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox6.Text = DataGridView1.Item(5, DataGridView1.CurrentRow.Index).Value.ToString()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
		End Try
	End Sub
	
	Sub BtnAddClick(sender As Object, e As EventArgs)
		Try
			db.connection.Open()
			db.query = "insert into tbl_boar (boar_alias,boar_birthdate,boar_breed,boar_source,boar_remarks) values (@alias,@bday,@breed,@source,@remarks);"
			db.command = New OleDbCommand(db.query,db.connection)
			db.command.Parameters.AddWithValue("@alias",textBox1.Text)
			db.command.Parameters.AddWithValue("@bday",textBox2.Text)
			db.command.Parameters.AddWithValue("@breed",textBox3.Text)
			db.command.Parameters.AddWithValue("@source",textBox5.Text)
			db.command.Parameters.AddWithValue("@remarks",textBox6.Text)
			db.command.ExecuteNonQuery()
			MessageBox.Show("Data Added!")
			db.connection.Close()
			loadData()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	Sub BtnDeleteClick(sender As Object, e As EventArgs)
		'Try
		'	db.connection.Open()
			'db.query="delete from tbl_boar where boar_id = @id;"
			'db.command = New OleDbCommand(db.query,db.connection)
			'db.command.Parameters.AddWithValue("@id",lblBoarID.Text)
			'db.command.ExecuteNonQuery()
			'MessageBox.Show("Data deleted!")
			'db.connection.Close()
			'loadData()
		'Catch ex As Exception
			'MessageBox.Show(ex.Message)
			'db.connection.Close()
			'End Try
			Try
			mainMenu.Show()
			mainMenu.lblCurrentUser.Text = Me.lblCurrentUser.Text
			Me.Hide()
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	Sub BtnUpdateClick(sender As Object, e As EventArgs)
		Try
			db.connection.Open()
			db.query = "update tbl_boar set boar_alias = @alias, boar_birthdate = @bday, boar_breed = @breed," & 
				"boar_source = @source, boar_remarks = @remarks where boar_id = @id;"
			db.command = New OleDbCommand(db.query,db.connection)
			db.command.Parameters.AddWithValue("@alias",textBox1.Text)
			db.command.Parameters.AddWithValue("@bday",textBox2.Text)
			db.command.Parameters.AddWithValue("@breed",textBox3.Text)
			db.command.Parameters.AddWithValue("@source",textBox5.Text)
			db.command.Parameters.AddWithValue("@remarks",textBox6.Text)
			db.command.Parameters.AddWithValue("@id",lblBoarID.Text)
			db.command.ExecuteNonQuery()
			MessageBox.Show("Data Updated!")
			db.connection.Close()
			loadData()
		Catch ex As Exception
			
		End Try
	End Sub
	
	Sub BtnSearchClick(sender As Object, e As EventArgs)
		Try
			db.connection.Open()
			db.query = "select * from tbl_boar where boar_id = " & Integer.Parse(textBox4.Text) &""
			Dim adapter As New OleDbDataAdapter(db.query, db.connection)
			Dim dt As New DataTable
			adapter.Fill(dt)
			dataGridView1.DataSource = dt
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			'If (db <> Nothing) AndAlso (db.connection <> Nothing) Then
			'End If
			db.connection.Close()
		End Try
	End Sub
	
	
	
	Sub Button1Click(sender As Object, e As EventArgs)
		loadData()
	End Sub
	
	
	
	Sub Button2Click(sender As Object, e As EventArgs)
'		printPreviewDialog1.Document = printDocument1
'		printPreviewDialog1.PrintPreviewControl.Zoom = 1
'		printPreviewDialog1.ShowDialog()
	End Sub
	
	
	Sub PrintDocument1PrintPage(sender As Object, e As System.Drawing.Printing.PrintPageEventArgs)
		''Working
		'Dim dataGridViewImage As New Bitmap(Me.dataGridView1.Width, Me.dataGridView1.Height)
		'Dim font As New Font("Arial",16,FontStyle.Regular)
		
		'dataGridView1.DrawToBitmap(dataGridViewImage, New Rectangle(0, 0, Me.dataGridView1.Width, Me.dataGridView1.Height))
		 
		 ''End Working
		''Working 
		'dataGridView1.DrawToBitmap(dataGridViewImage, New Rectangle(0, 0, Me.dataGridView1.Width, Me.dataGridView1.Height))
		'e.Graphics.DrawString("Alyas: ",font, Brushes.Black, 50,8)
		'e.Graphics.DrawString(textBox1.Text,font, Brushes.Black, 120,8)
		
	'	e.Graphics.DrawString("Date: ",font, Brushes.Black, 50,50)
	'	e.Graphics.DrawString(textBox2.Text,font, Brushes.Black, 120,50)
		
	'	e.Graphics.DrawString("Breed: ",font, Brushes.Black, 350,8)
	'	e.Graphics.DrawString(textBox3.Text,font, Brushes.Black, 420,8)
		
	'	e.Graphics.DrawString("Source: ",font, Brushes.Black, 350,50)
	'	e.Graphics.DrawString(textBox5.Text,font, Brushes.Black, 430,50)
		
		
		'	e.Graphics.DrawImage(dataGridViewImage, 50, 50)
	'	e.Graphics.DrawImage(dataGridViewImage, 100, 100)
	''End Working
	End Sub
End Class
