﻿'
' Created by SharpDevelop.
' User: John Oliver Amurao
' Date: 4 Mar 2019
' Time: 3:59 AM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System.Data
Imports System.Data.OleDb

Public Partial Class SowManagement
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Dim db As New DatabaseHelper
	Dim mainMenu As New MainMenu
	
	Sub Label4Click(sender As Object, e As EventArgs)
		Try
			mainMenu.Show()
			mainMenu.lblCurrentUser.Text = Me.lblCurrentUser.Text
			Me.Hide()
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	Sub loadData()
		Try
			db.connection.Open()
			db.query = "select * from sowlist"
			Dim adapter As New OleDbDataAdapter(db.query, db.connection)
			Dim dt As New DataTable
			adapter.Fill(dt)
			dataGridView1.DataSource = dt
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	Sub SowManagementLoad(sender As Object, e As EventArgs)
		loadData()		
	End Sub
	
	Sub DataGridView1CellClick(sender As Object, e As DataGridViewCellEventArgs)
		Try
			lblSowID.Text = DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox1.Text = DataGridView1.Item(1, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox2.Text = DataGridView1.Item(2, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox3.Text = DataGridView1.Item(3, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox4.Text = DataGridView1.Item(4, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox5.Text = DataGridView1.Item(5, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox6.Text = DataGridView1.Item(6, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox7.Text = DataGridView1.Item(7, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox8.Text = DataGridView1.Item(8, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox9.Text = DataGridView1.Item(9, DataGridView1.CurrentRow.Index).Value.ToString()
			textBox10.Text = DataGridView1.Item(10, DataGridView1.CurrentRow.Index).Value.ToString()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
		End Try
	End Sub
	
	Sub BtnAddClick(sender As Object, e As EventArgs)
		Try
			db.connection.Open()
			db.query = "INSERT INTO tbl_sowlist (sow_alias,breed,birth_date,date_acquired,type,source,status,date_culled,owner,remarks) values "&
				"(@alias,@breed,@birth_date,@date_acquired,@type,@source,@status,@date_culled,@owner,@remarks)"
			db.command = New OleDbCommand(db.query,db.connection)	
			db.command.Parameters.AddWithValue("@alias",textBox1.Text)
			db.command.Parameters.AddWithValue("@breed",textBox2.Text)
			db.command.Parameters.AddWithValue("@birth_date",textBox3.Text)
			db.command.Parameters.AddWithValue("@date_acquired",textBox4.Text)
			db.command.Parameters.AddWithValue("@type",textBox5.Text)
			db.command.Parameters.AddWithValue("@source",textBox6.Text)
			db.command.Parameters.AddWithValue("@status",textBox7.Text)
			db.command.Parameters.AddWithValue("@date_culled",textBox8.Text)
			db.command.Parameters.AddWithValue("@owner",textBox9.Text)
			db.command.Parameters.AddWithValue("@remarks",textBox10.Text)
			db.command.ExecuteNonQuery()
			MessageBox.Show("Data Added!")
			db.connection.Close()
			loadData()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	Sub BtnDeleteClick(sender As Object, e As EventArgs)
		'Try
			'db.connection.Open()
			'db.query = "delete from tbl_sowlist where sow_id = @id"
			'db.command = New OleDbCommand(db.query, db.connection)
			'db.command.Parameters.AddWithValue("@id",lblSowID.Text)
			'db.command.ExecuteNonQuery()
			'MessageBox.Show("Data deleted!")
			'db.connection.Close()
			'loadData()
		'Catch ex As Exception
			'MessageBox.Show(ex.Message)
			'db.connection.Close()
			'End Try
			
			Try
			mainMenu.Show()
			mainMenu.lblCurrentUser.Text = Me.lblCurrentUser.Text
			Me.Hide()
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	Sub BtnUpdateClick(sender As Object, e As EventArgs)
		Try
			db.connection.Open()
			db.query = "update tbl_sowlist set sow_alias = @alias, breed = @breed, birth_date = @birth_date, " & 
				"date_acquired = @date_acquired, type = @type, source = @source, status = @status,"&
				"date_culled = @date_culled, owner = @owner, remarks = @remarks where sow_id = @id;"
			db.command = New OleDbCommand(db.query,db.connection)	
			db.command.Parameters.AddWithValue("@alias",textBox1.Text)
			db.command.Parameters.AddWithValue("@breed",textBox2.Text)
			db.command.Parameters.AddWithValue("@birth_date",textBox3.Text)
			db.command.Parameters.AddWithValue("@date_acquired",textBox4.Text)
			db.command.Parameters.AddWithValue("@type",textBox5.Text)
			db.command.Parameters.AddWithValue("@source",textBox6.Text)
			db.command.Parameters.AddWithValue("@status",textBox7.Text)
			db.command.Parameters.AddWithValue("@date_culled",textBox8.Text)
			db.command.Parameters.AddWithValue("@owner",textBox9.Text)
			db.command.Parameters.AddWithValue("@remarks",textBox10.Text)
			db.command.Parameters.AddWithValue("@id",lblSowID.Text)
			db.command.ExecuteNonQuery()
			MessageBox.Show("Data Updated!")
			db.connection.Close()
			loadData()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			db.connection.Close()
		End Try
	End Sub
	
	
	Sub Button1Click(sender As Object, e As EventArgs)
		loadData()
	End Sub
	
	Sub BtnSearch1Click(sender As Object, e As EventArgs)
		Try
			db.connection.Open()
			'db.query = "select * from tbl_sowlist where sow_id = " & Integer.Parse(textBox11.Text) & " "
			'Dim adapter As New OleDbDataAdapter(db.query, db.connection)
			'Dim dt As New DataTable
			'adapter.Fill(dt)
			'dataGridView1.DataSource = dt
			db.connection.Close()
		Catch ex As Exception
			MessageBox.Show(ex.Message)
			
			db.connection.Close()
			
		End Try
	End Sub
End Class
